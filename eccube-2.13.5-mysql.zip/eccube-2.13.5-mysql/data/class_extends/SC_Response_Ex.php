<?php

require_once CLASS_REALDIR . 'SC_Response.php';

class SC_Response_Ex extends SC_Response
{
}
